/* 
    Name: Ambar Cerino
    File: a4p4.js
    Date: 03 April, 2026
    Description: assignment 4 part 4 javascript 
*/

// Create a Shape class
class Shape {
    constructor(x, y, velX, velY) {
        this.x = x;
        this.y = y;
        this.velX = velX;
        this.velY = velY;
    }

}

const ballCount = document.querySelector("p")
let count = 0;

const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");

const width = (canvas.width = window.innerWidth);
const height = (canvas.height = window.innerHeight);


function random(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomRGB() {
    return `rgb(${random(0, 255)} ${random(0, 255)} ${random(0, 255)})`;
}

//Modeling a ball
class Ball extends Shape {
    constructor(x, y, velX, velY, color, size) {
        super(x, y, velX, velY);
        this.color = color;
        this.size = size;
        this.exists = true;
    }

    // Drawing the ball
    draw() {
        ctx.beginPath();
        ctx.fillStyle = this.color;
        ctx.arc(this.x, this.y, this.size, 0, 2 * Math.PI);
        ctx.fill();
    }

    //Updating the ball's data
    update() {
        if (this.x + this.size >= width) {
            this.velX = -this.velX
        }
        if (this.x + this.size <= 0) {
            this.velX = -this.velX
        }
        if (this.y + this.size >= height) {
            this.velY = -this.velY
        }
        if (this.y + this.size <= 0) {
            this.velY = -this.velY
        }
        this.x += this.velX;
        this.y += this.velY;
    }

    // Raplacing collision detection 
    collisionDetect() {
        for (const ball of balls) {
            if (!(this === ball) && ball.exists) {
                const dx = this.x - ball.x;
                const dy = this.y - ball.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < this.size + ball.size) {
                    ball.color = this.color = randomRGB();
                }
            }
        }
    }
}

// Defining EvilCircle
class EvilCircle extends Shape {
    // EvilCircle constructor
    constructor(x, y) {
        super(x, y, 20, 20);
        this.color = "white";
        this.size = 10;

        window.addEventListener("keydown", (e) => {
            switch (e.key) {
                case "a":
                    this.x -= this.velX;
                    break;
                case "d":
                    this.x += this.velX;
                    break;
                case "w":
                    this.y -= this.velY;
                    break;
                case "s":
                    this.y += this.velY;
                    break;
            }
        });
    }

    //Defining Methods for EvilCircle
    // draw method
    draw() {
        ctx.beginPath();
        ctx.strokeStyle = this.color;
        ctx.arc(this.x, this.y, this.size, 0, 2 * Math.PI);
        ctx.stroke();
        ctx.lineWidth = 3;
    }
    //Check Bounds method
    checkBounds() {
        if (this.x + this.size >= width) {
            this.x -= this.size
        }
        if (this.x + this.size <= 0) {
            this.x -= this.size
        }
        if (this.y + this.size >= height) {
            this.y -= this.size
        }
        if (this.y + this.size <= 0) {
            this.y -= this.size
        }
    }
    // collision detect method
    collisionDetect() {
         for (const ball of balls) {
            if (ball.exists) {
                const dx = this.x - ball.x;
                const dy = this.y - ball.y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < this.size + ball.size) {
                    ball.exists = false;
                    count--;
                    ballCount.textContent = `Ball count: ${count}`;
                }
            }
        }
    }
}

const balls = [];

// Animating the ball
while (balls.length < 25) {
    const size = random(10, 20);
    const ball = new Ball(
        random(0 + size, width - size),
        random(0 + size, height - size),
        random(-7, 7),
        random(-7, 7),
        randomRGB(),
        size,
    );
    balls.push(ball);
    count++;
    ballCount.textContent = `Ball count: ${count}`;
}

const evilCircle = new EvilCircle (
    random(0, width),
    random(0,height)
);
// Bringing the evil circle into the program
// Changes to the loop function
function loop() {
    ctx.fillStyle = "rgb(0 0 0 / 25%)";
    ctx.fillRect(0, 0, width, height);
    for (const ball of balls) {
        if (ball.exists) {
            ball.draw();
            ball.update();
            ball.collisionDetect();
        }
    }
    evilCircle.draw();
    evilCircle.checkBounds();
    evilCircle.collisionDetect();

    requestAnimationFrame(loop);
}

loop();
